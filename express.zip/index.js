const express = require('express');
const morgan = require('morgan');
const { checkEmail } = require('./checkEmail');
const app = express();


const checkPassword = (request, response, next) => {
    request.pepe ='pepe'
    const password = request.body.password
    if(password.length < 3) {
        return response.json({message: 'Password not valid'})
    }
    next()
}

const secondMiddleware = (request, response, next) => {
    console.log(request.pepe)
    console.log('second middleware')
    next()
}
app.use(express.json()) //transforma el formato json a un formato que lo pueda leer javascript.
app.use(morgan('dev'))
app.use(express.static('public'));// apunta a la carpeta de nombre que nosotros tenemos y en el postman podrás hacer la peticion para verla.
app.use(checkPassword)
app.use(checkEmail)
app.use(secondMiddleware)

app.get('/api/:userId/algomas', (request, response) => {
    //console.log(request.params);
    console.log(request.query);
    return response.json({mensage: 'lo qe quiera'})
  })

  app.post('/api/post', (request, response) => {
    console.log(request.pepe)
    console.log(request.body)
    return response.json({mensage: 'haz hecho un post'})
  })

  app.listen(3000, ()=>{
    console.log('server start')
  })