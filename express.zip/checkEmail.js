var validator = require("email-validator");

const checkEmail = (request, response, next) => {
    const isEmail = validator.validate(request.body.email);
    if (!isEmail) {
        return response.json({ message: 'Email not valid' });
    }
    next();
};
exports.checkEmail = checkEmail;
